<?php
header('location: Views/home');
?>
